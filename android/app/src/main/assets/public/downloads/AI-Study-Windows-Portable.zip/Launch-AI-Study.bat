@echo off
start "" "%~dp0AI-Study.exe"
