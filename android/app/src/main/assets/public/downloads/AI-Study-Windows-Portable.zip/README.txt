AI Study - Portable Edition 2.4.0
==========================================

Usage:
1. Double-click "AI-Study.exe" or "Launch-AI-Study.bat" to start.
2. (Optional) Run "Create-Desktop-Shortcut.vbs" to pin to your desktop.
3. Fully self-contained. No administrator permissions needed.

Connected Backend:
https://ais-pre-5uo5pgogykgk4hpol5v7si-876828252560.europe-west2.run.app/?view=app
