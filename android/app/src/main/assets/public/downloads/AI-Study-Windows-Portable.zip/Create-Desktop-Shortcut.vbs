Set oWS = WScript.CreateObject("WScript.Shell")
sLinkFile = oWS.SpecialFolders("Desktop") & "\AI Study.lnk"
Set oLink = oWS.CreateShortcut(sLinkFile)
oLink.TargetPath = oWS.CurrentDirectory & "\AI-Study.exe"
oLink.IconLocation = oWS.CurrentDirectory & "\AI-Study.ico"
oLink.Description = "AI Study - Intelligent Learning Platform"
oLink.WorkingDirectory = oWS.CurrentDirectory
oLink.Save
MsgBox "Desktop shortcut created successfully!", vbInformation, "AI Study"
